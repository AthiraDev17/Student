Here you will find the datasets referenced in Ron Cody's *Learning SAS by Example: A Programmer's Guide, Second Edition*. 
 